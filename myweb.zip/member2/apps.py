from django.apps import AppConfig


class Member2Config(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'member2'
